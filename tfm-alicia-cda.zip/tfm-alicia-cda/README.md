# Development of a Damage Detection System for Wind Turbine Blades using a Siamese Neural Network

### Fine Tuning Siamese.ipynb
Código principal para entrenar la red

### /functions
- *train.py*: training script
- *siamese_resnet.py*: definición red siamesa
- *~~pair_dataset.py~*: creación dataset de pares (clase dataset modificada)
- *~~net_train.py~~*: generación de batches

